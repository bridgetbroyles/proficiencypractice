#include "reader.h"

int calculate_result(struct Reader* reader);